require_dependency 'generador_facturas'

class SaludosController < ApplicationController
  def menu
    # No implementacion, es para el menu
  end

  def index
    Producto.cargar_productos unless Producto.todos.any?
    @productos = Producto.todos
  end

  def crear_producto
    begin
      producto = Producto.new(
        params[:nombre],
        params[:precio],
        params[:cantidad]
      )
      
      render json: { 
        mensaje: "Producto creado: #{producto.nombre}",
        producto: {
          id: producto.id,
          nombre: producto.nombre,
          precio: producto.precio,
          cantidad: producto.cantidad
        }
      }
    rescue ArgumentError => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def actualizar_producto
    producto = Producto.actualizar(
      params[:id].to_i,
      nombre: params[:nombre],
      precio: params[:precio],
      cantidad: params[:cantidad]
    )

    if producto
      render json: { 
        mensaje: "Producto actualizado",
        producto: {
          id: producto.id,
          nombre: producto.nombre,
          precio: producto.precio,
          cantidad: producto.cantidad
        }
      }
    else
      render json: { error: "Producto no encontrado" }, status: :not_found
    end
  end

  def eliminar_producto
    producto = Producto.buscar_por_id(params[:id].to_i)
    
    if producto
      producto.eliminar
      render json: { mensaje: "Producto eliminado" }
    else
      render json: { error: "Producto no encontrado" }, status: :not_found
    end
  end

  def clientes
    Cliente.cargar_clientes unless Cliente.todos.any?
    @clientes = Cliente.todos
  end

  def crear_cliente
    begin
      cliente = Cliente.new(
        params[:nombre],
        params[:telefono]
      )
      
      render json: { 
        mensaje: "Cliente creado: #{cliente.nombre}",
        cliente: {
          id: cliente.id,
          nombre: cliente.nombre,
          telefono: cliente.telefono
        }
      }
    rescue ArgumentError => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def actualizar_cliente
    cliente = Cliente.actualizar(
      params[:id].to_i,
      nombre: params[:nombre],
      telefono: params[:telefono]
    )

    if cliente
      render json: { 
        mensaje: "Cliente actualizado",
        cliente: {
          id: cliente.id,
          nombre: cliente.nombre,
          telefono: cliente.telefono
        }
      }
    else
      render json: { error: "Cliente no encontrado" }, status: :not_found
    end
  end

  def eliminar_cliente
    cliente = Cliente.buscar_por_id(params[:id].to_i)
    
    if cliente
      cliente.eliminar
      render json: { mensaje: "Cliente eliminado" }
    else
      render json: { error: "Cliente no encontrado" }, status: :not_found
    end
  end

  def facturar
    @clientes = Cliente.todos
    @productos = Producto.todos
    @impuestos = Impuesto.todos
  end

  def crear_factura
    begin
      factura_params = {
        cliente_id: params.dig(:factura, :cliente_id).to_i,
        productos_attributes: Array(params.dig(:factura, :productos_attributes)).map do |p|
          {
            producto_id: p[:producto_id] || p["producto_id"] || 0,
            cantidad: p[:cantidad] || p["cantidad"] || 0
          }.transform_values(&:to_i)
        end,
        impuestos_ids: Array(params[:impuestos]).map(&:to_i)
      }

      # Validaciones
      if factura_params[:cliente_id] <= 0
        return render json: { error: "Cliente no válido" }, status: :unprocessable_entity
      end

      if factura_params[:productos_attributes].empty?
        return render json: { error: "No hay productos" }, status: :unprocessable_entity
      end

      productos_factura = factura_params[:productos_attributes].map do |p|
        producto = Producto.buscar_por_id(p[:producto_id])
        unless producto
          return render json: { error: "Producto no encontrado" }, status: :not_found
        end

        if producto.cantidad < p[:cantidad]
          return render json: { error: "Stock insuficiente de #{producto.nombre}" }, status: :unprocessable_entity
        end

        {
          id: producto.id,
          nombre: producto.nombre,
          precio: producto.precio,
          cantidad: p[:cantidad]
        }
      end

      # Actualizar el stock
      factura_params[:productos_attributes].each do |p|
        producto = Producto.buscar_por_id(p[:producto_id])
        producto.cantidad -= p[:cantidad]
        Producto.actualizar(
          producto.id,
          cantidad: producto.cantidad
        )
      end

      # Crear la factura después de actualizar
      factura = Factura.new(factura_params[:cliente_id], productos_factura, factura_params[:impuestos_ids])
      
      render json: {
        mensaje: "Factura creada correctamente",
        factura_id: factura.id
      }
    rescue => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def factura_pdf
    @factura = Factura.buscar_por_id(params[:id].to_i)
    
    if @factura.nil?
      redirect_to facturar_path, alert: "Factura no encontrada"
      return
    end
    
    respond_to do |format|
      format.pdf do
        pdf = Prawn::Document.new(page_size: 'A4') do
          text "Factura ##{@factura.id}", size: 18, style: :bold, align: :center
          move_down 20
          
          text "Cliente: #{@factura.cliente.nombre}", size: 12
          text "Fecha: #{@factura.fecha.strftime('%d/%m/%Y %H:%M')}", size: 12
          move_down 30

          items = [["Producto", "Cantidad", "Precio Unitario", "Subtotal"]]
          
          @factura.productos.each do |p|
            items << [
              p[:nombre],
              p[:cantidad],
              "$#{'%.2f' % p[:precio]}",
              "$#{'%.2f' % (p[:precio] * p[:cantidad])}"
            ]
          end

          items << ["", "", "Subtotal:", "$#{'%.2f' % @factura.subtotal}"]

          @factura.impuestos.each do |impuesto|
            monto = @factura.subtotal * (impuesto.porcentaje / 100.0)
            items << ["", "", "#{impuesto.nombre} (#{impuesto.porcentaje}%):", "$#{'%.2f' % monto}"]
          end

          items << ["", "", "TOTAL:", "$#{'%.2f' % @factura.total}"]
          
          table(items, width: bounds.width, cell_style: { borders: [] }) do
            row(0).font_style = :bold
            row(-3).borders = [:top]
            row(-1).font_style = :bold
            row(-1).borders = [:top]
          end
        end

        # JSON temporal para pdf
        json_data = {
          id: @factura.id,
          cliente_id: @factura.cliente_id,
          productos: @factura.productos,
          fecha: @factura.fecha.to_s
        }.to_json

        File.write('temp_factura.json', json_data)
        generar_factura_pdf('temp_factura.json', "public/facturas/factura_#{@factura.id}.pdf") # Cada factura se almacena con el id

        send_file "public/facturas/factura_#{@factura.id}.pdf",
                  type: 'application/pdf',
                  disposition: :inline
        
        send_data pdf.render,
                  filename: "factura_#{@factura.id}.pdf",
                  type: 'application/pdf',
                  disposition: :inline
      end
    end
  rescue => e
    redirect_to facturar_path, alert: "Error al generar PDF: #{e.message}"
  end

  def impuestos
    Impuesto.cargar_impuestos unless Impuesto.todos.any?
    @impuestos = Impuesto.todos
  end

  def crear_impuesto
    begin
      impuesto = Impuesto.new(
        params[:nombre],
        params[:porcentaje]
      )
      
      render json: {
        mensaje: "Impuesto creado: #{impuesto.nombre}",
        impuesto: {
          id: impuesto.id,
          nombre: impuesto.nombre,
          porcentaje: impuesto.porcentaje
        }
      }
    rescue ArgumentError => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def actualizar_impuesto
    impuesto = Impuesto.actualizar(
      params[:id].to_i,
      nombre: params[:nombre],
      porcentaje: params[:porcentaje]
    )
    if impuesto
      render json: {
        mensaje: "Impuesto actualizado",
        impuesto: {
          id: impuesto.id,
          nombre: impuesto.nombre,
          porcentaje: impuesto.porcentaje
        }
      }
    else
      render json: { error: "Impuesto no encontrado" }, status: :not_found
    end
  end

  def eliminar_impuesto
    impuesto = Impuesto.buscar_por_id(params[:id].to_i)
    
    if impuesto
      impuesto.eliminar
      render json: { mensaje: "Impuesto eliminado" }
    else
      render json: { error: "Impuesto no encontrado" }, status: :not_found
    end
  end
end