class SaludosController < ApplicationController
  def menu
    # No implementacion, es para el menu
  end

  def index
    Producto.cargar_productos unless Producto.todos.any?
    @productos = Producto.todos
  end

  def crear_producto
    begin
      producto = Producto.new(
        params[:nombre],
        params[:precio],
        params[:cantidad]
      )
      
      render json: { 
        mensaje: "Producto creado: #{producto.nombre}",
        producto: {
          id: producto.id,
          nombre: producto.nombre,
          precio: producto.precio,
          cantidad: producto.cantidad
        }
      }
    rescue ArgumentError => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def actualizar_producto
    producto = Producto.actualizar(
      params[:id].to_i,
      nombre: params[:nombre],
      precio: params[:precio],
      cantidad: params[:cantidad]
    )

    if producto
      render json: { 
        mensaje: "Producto actualizado",
        producto: {
          id: producto.id,
          nombre: producto.nombre,
          precio: producto.precio,
          cantidad: producto.cantidad
        }
      }
    else
      render json: { error: "Producto no encontrado" }, status: :not_found
    end
  end

  def eliminar_producto
    producto = Producto.buscar_por_id(params[:id].to_i)
    
    if producto
      producto.eliminar
      render json: { mensaje: "Producto eliminado" }
    else
      render json: { error: "Producto no encontrado" }, status: :not_found
    end
  end

  def clientes
    Cliente.cargar_clientes unless Cliente.todos.any?
    @clientes = Cliente.todos
  end

  def crear_cliente
    begin
      cliente = Cliente.new(
        params[:nombre],
        params[:telefono]
      )
      
      render json: { 
        mensaje: "Cliente creado: #{cliente.nombre}",
        cliente: {
          id: cliente.id,
          nombre: cliente.nombre,
          telefono: cliente.telefono
        }
      }
    rescue ArgumentError => e
      render json: { error: e.message }, status: :unprocessable_entity
    end
  end

  def actualizar_cliente
    cliente = Cliente.actualizar(
      params[:id].to_i,
      nombre: params[:nombre],
      telefono: params[:telefono]
    )

    if cliente
      render json: { 
        mensaje: "Cliente actualizado",
        cliente: {
          id: cliente.id,
          nombre: cliente.nombre,
          telefono: cliente.telefono
        }
      }
    else
      render json: { error: "Cliente no encontrado" }, status: :not_found
    end
  end

  def eliminar_cliente
    cliente = Cliente.buscar_por_id(params[:id].to_i)
    
    if cliente
      cliente.eliminar
      render json: { mensaje: "Cliente eliminado" }
    else
      render json: { error: "Cliente no encontrado" }, status: :not_found
    end
  end
end