class ClientesController < ApplicationController
end
