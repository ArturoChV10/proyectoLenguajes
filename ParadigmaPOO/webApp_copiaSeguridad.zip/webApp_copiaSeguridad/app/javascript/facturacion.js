
document.addEventListener('DOMContentLoaded', function() {
  let productosSeleccionados = [];
  
  const actualizarEstilosStock = () => {
    document.querySelectorAll('.tabla-productos tbody tr').forEach(row => {
      const stockCell = row.querySelector('.stock');
      const stock = parseInt(row.dataset.stock);
      
      if (stock <= 5) {
        stockCell.classList.add('stock-bajo');
        stockCell.classList.remove('stock-normal');
      } else {
        stockCell.classList.add('stock-normal');
        stockCell.classList.remove('stock-bajo');
      }
    });
  };

  actualizarEstilosStock();

  const impuestosElements = document.querySelectorAll('.impuesto-data');
  const impuestosData = Array.from(impuestosElements).map(el => ({
    id: parseInt(el.dataset.id),
    nombre: el.dataset.nombre,
    porcentaje: parseFloat(el.dataset.porcentaje)
  }));
  
  // Actualizar productos a facturar
  const actualizarResumen = () => {
    const resumen = document.getElementById('resumen-factura');
    const totalElement = document.getElementById('total-factura');
    const btnGenerar = document.getElementById('generar-factura');
    const impuestosSeleccionados = Array.from(document.querySelectorAll('.impuesto-checkbox:checked')).map(cb => Number(cb.value));
    
    if (productosSeleccionados.length === 0) {
      resumen.innerHTML = '<p>No hay productos agregados</p>';
      totalElement.innerHTML = '<strong>Total: $0.00</strong>';
      btnGenerar.disabled = true;
      return;
    }
    
    let subtotal = 0;
    let html = `
      <table class="tabla-resumen">
        <thead>
          <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unitario</th>
            <th>Subtotal</th>
          </tr>
        </thead>
        <tbody>
    `;
    
    productosSeleccionados.forEach(item => {
      const itemSubtotal = item.precio * item.cantidad;
      subtotal += itemSubtotal;
      
      html += `
        <tr>
          <td>${item.nombre}</td>
          <td>${item.cantidad}</td>
          <td>$${item.precio.toFixed(2)}</td>
          <td>$${itemSubtotal.toFixed(2)}</td>
        </tr>
      `;
    });
    
    // Manjeo de impuestos
    const impuestosElements = document.querySelectorAll('.impuesto-data');
    const impuestosData = Array.from(impuestosElements).map(el => ({
      id: parseInt(el.dataset.id),
      nombre: el.dataset.nombre,
      porcentaje: parseFloat(el.dataset.porcentaje)
    }));

    let totalImpuestos = 0;
    const impuestosAplicados = impuestosSeleccionados.map(id => {
      const impuesto = impuestosData.find(i => i.id === id);
      if (impuesto) {
        const montoImpuesto = subtotal * (impuesto.porcentaje / 100);
        totalImpuestos += montoImpuesto;
        return { 
          nombre: impuesto.nombre, 
          porcentaje: impuesto.porcentaje, 
          monto: montoImpuesto 
        };
      }
      return null;
    }).filter(i => i !== null);
    
    html += `
      <tr class="subtotal-row">
        <td colspan="3" style="text-align: right;"><strong>Subtotal:</strong></td>
        <td><strong>$${subtotal.toFixed(2)}</strong></td>
      </tr>
    `;
    
    impuestosAplicados.forEach(impuesto => {
      html += `
        <tr class="impuesto-row">
          <td colspan="3" style="text-align: right;">${impuesto.nombre} (${impuesto.porcentaje}%):</td>
          <td>$${impuesto.monto.toFixed(2)}</td>
        </tr>
      `;
    });
    
    const total = subtotal + totalImpuestos;
    
    html += `
      <tr class="total-row">
        <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
        <td><strong>$${total.toFixed(2)}</strong></td>
      </tr>
      </tbody>
      </table>
    `;
    
    resumen.innerHTML = html;
    totalElement.innerHTML = `<strong>Total: $${total.toFixed(2)}</strong>`;
    btnGenerar.disabled = false;
  };
  
  // Evento para agregar
document.querySelectorAll('.btn-agregar').forEach(btn => {
  btn.addEventListener('click', function() {
    const fila = this.closest('tr');
    const productoId = fila.dataset.productoId;
    const nombre = fila.querySelector('td:first-child').textContent;
    const precio = parseFloat(fila.querySelector('td:nth-child(2)').textContent.replace('$', ''));
    const stock = parseInt(fila.dataset.stock);
    const inputCantidad = fila.querySelector('.cantidad');
    let cantidad = parseInt(inputCantidad.value);

    cantidad = isNaN(cantidad) ? 0 : Math.max(0, cantidad);
    cantidad = Math.min(cantidad, stock);
    
    if (cantidad <= 0) {
      productosSeleccionados = productosSeleccionados.filter(p => p.id !== productoId);
      inputCantidad.value = 0;
    } else {
      const index = productosSeleccionados.findIndex(p => p.id === productoId);
      
      if (index !== -1) {
        productosSeleccionados[index].cantidad = cantidad;
      } else {
        productosSeleccionados.push({
          id: productoId,
          nombre: nombre,
          precio: precio,
          cantidad: cantidad
        });
      }
    }
    
    // Actualizar stock
    const nuevoStock = stock - cantidad;
    fila.dataset.stock = nuevoStock;
    const stockCell = fila.querySelector('.stock');
    stockCell.textContent = nuevoStock;
    
    // Colores de la cantidad
    if (nuevoStock <= 5) {
      stockCell.classList.add('stock-bajo');
      stockCell.classList.remove('stock-normal');
    } else {
      stockCell.classList.add('stock-normal');
      stockCell.classList.remove('stock-bajo');
    }
    
    inputCantidad.max = nuevoStock;
    
    actualizarResumen();
  });
});
  
  // Evento para generar factura
document.getElementById('generar-factura')?.addEventListener('click', async function() {

  const btnGenerar = this;
  btnGenerar.disabled = true;
  
    try {
      if (productosSeleccionados.length === 0) {
        throw new Error('Debes agregar al menos un producto');
      }

      productosSeleccionados.forEach(p => {
        const stockDisponible = parseInt(document.querySelector(`tr[data-producto-id="${p.id}"]`).dataset.stock);
        if (p.cantidad > stockDisponible) {
          throw new Error(`No hay suficiente stock de ${p.nombre} (disponibles: ${stockDisponible})`);
        }
      });

      const payload = {
        factura: {
          cliente_id: Number(document.getElementById('cliente_id').value),
          productos_attributes: productosSeleccionados.map(p => ({
            producto_id: Number(p.id),
            cantidad: Number(p.cantidad)
          })),
          impuestos_ids: Array.from(document.querySelectorAll('.impuesto-checkbox:checked')).map(cb => Number(cb.value))
        }
      };

      const loader = document.createElement('div');
      loader.className = 'loader';
      btnGenerar.parentNode.insertBefore(loader, btnGenerar.nextSibling);

      const response = await fetch('/crear_factura', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify(payload)
      });

      loader.remove();

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || 'Error en el servidor');
      }

      const data = await response.json();

      if (!data.factura_id) {
        throw new Error('No se recibió ID de factura');
      }

      // Vetana para pdf
      window.open(`/factura_pdf/${data.factura_id}.pdf`, '_blank');

      // Recargar la página
      location.reload();

    } catch (error) {
      console.error('Error:', error);
      
      // Mensaje de error
      let errorContainer = document.getElementById('error-container');
      if (!errorContainer) {
        errorContainer = document.createElement('div');
        errorContainer.id = 'error-container';
        errorContainer.style.cssText = `
          position: fixed;
          top: 20px;
          right: 20px;
          padding: 15px;
          background: #ffebee;
          color: #c62828;
          border-left: 4px solid #ef5350;
          border-radius: 4px;
          z-index: 1000;
          max-width: 400px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        `;
        document.body.appendChild(errorContainer);
      }
      
      errorContainer.innerHTML = `
        <p><strong>Error:</strong> ${error.message}</p>
        <button onclick="this.parentNode.remove()" style="
          background: none;
          border: none;
          color: #c62828;
          cursor: pointer;
          float: right;
        ">✕</button>
      `;
      
    } finally {
      btnGenerar.disabled = false;
    }
  });
  // ==============================================
});