Rails.application.routes.draw do
  root 'saludos#menu'
  get 'productos', to: 'saludos#index'
  get 'clientes', to: 'saludos#clientes'
  post 'crear_producto', to: 'saludos#crear_producto'
  put 'actualizar_producto/:id', to: 'saludos#actualizar_producto'
  delete 'eliminar_producto/:id', to: 'saludos#eliminar_producto'
  post 'crear_cliente', to: 'saludos#crear_cliente'
  put 'actualizar_cliente/:id', to: 'saludos#actualizar_cliente'
  delete 'eliminar_cliente/:id', to: 'saludos#eliminar_cliente'
end