class Impuesto
  attr_accessor :nombre, :porcentaje
  attr_reader :id

  @@impuestos = []
  @@contador = 0
  @@archivo = Rails.root.join('public', 'impuestos.txt')

  def initialize(nombre, porcentaje)
    @@contador += 1
    @id = @@contador
    self.nombre = nombre
    self.porcentaje = porcentaje
    @@impuestos << self
    self.class.guardar_impuestos
  end

  def nombre=(nombre)
    if nombre.is_a?(String) && !nombre.empty?
      @nombre = nombre
    else
      raise ArgumentError, "Nombre debe ser un string no vacío"
    end
  end

  def porcentaje=(porcentaje)
    porcentaje_num = porcentaje.is_a?(String) ? Float(porcentaje) : porcentaje
    if porcentaje_num.is_a?(Numeric) && porcentaje_num >= 0
      @porcentaje = porcentaje_num
    else
      raise ArgumentError, "Porcentaje debe ser un número positivo"
    end
  end

  class << self
    def todos
      @@impuestos
    end

    def cargar_impuestos
      return unless File.exist?(@@archivo)
      
      @@impuestos.clear
      File.readlines(@@archivo).each do |linea|
        datos = linea.strip.split(',')
        Impuesto.new(datos[1], datos[2]) if datos.size == 3
      end
    end

    def guardar_impuestos
      File.open(@@archivo, 'w') do |file|
        @@impuestos.each do |impuesto|
          file.puts "#{impuesto.id},#{impuesto.nombre},#{impuesto.porcentaje}"
        end
      end
    end

    def buscar_por_id(id)
      @@impuestos.find { |i| i.id == id }
    end

    def actualizar(id, nuevos_datos)
      impuesto = buscar_por_id(id)
      return false unless impuesto

      impuesto.nombre = nuevos_datos[:nombre] if nuevos_datos[:nombre]
      impuesto.porcentaje = nuevos_datos[:porcentaje] if nuevos_datos[:porcentaje]
      
      guardar_impuestos
      impuesto
    end
  end

  def eliminar
    @@impuestos.delete(self)
    self.class.guardar_impuestos
  end

  def to_s
    "#{nombre} (#{porcentaje}%)"
  end
end

# Cargar impuestos
Impuesto.cargar_impuestos