require 'json'
require 'prawn'
require 'prawn/table'
require 'date'
class GeneradorFacturas
  def self.generar(archivo_json, output_path = 'factura.pdf')
    datos = JSON.parse(File.read(archivo_json))

    factura_id = datos['id']
    productos = datos['productos']
    fecha = DateTime.parse(datos['fecha']).strftime("%d/%m/%Y %H:%M")

    subtotal = productos.sum { |p| p['precio'] * p['cantidad'] }
    iva = subtotal * 0.16
    total = subtotal + iva
    
    Prawn::Document.generate(output_path, page_size: 'A4', margin: [40, 75, 40, 75]) do |pdf|
      pdf.font "Helvetica"
      pdf.font_size 10
      
      begin
        pdf.image 'logo.png', width: 100, position: :center if File.exist?('logo.png')
      rescue

      end
      

      pdf.move_down 20
      pdf.text "FACTURA ##{factura_id}", size: 18, style: :bold, align: :center
      pdf.move_down 10
      
      pdf.float do
        pdf.bounding_box([pdf.bounds.right - 200, pdf.cursor], width: 200) do
          pdf.text "Fecha: #{fecha}", align: :right
          pdf.text "N° Factura: #{factura_id}", align: :right
        end
      end
      
      pdf.move_down 30
      
      items = [["Código", "Descripción", "Precio Unitario", "Cantidad", "Total"]]
      
      productos.each do |producto|
        items << [
          producto['id'].to_s,
          producto['nombre'],
          "$#{'%.2f' % producto['precio']}",
          producto['cantidad'].to_s,
          "$#{'%.2f' % (producto['precio'] * producto['cantidad'])}"
        ]
      end
      
      pdf.table(items, header: true, width: pdf.bounds.width) do |table|
        table.row(0).font_style = :bold
        table.row(0).background_color = "f0f0f0"
        table.row(0).align = :center
        table.columns(2..4).align = :right
        table.row(-1).borders = [:bottom]
        table.cells.borders = []
        table.cells.padding = [5, 5, 5, 5]
      end
      
      pdf.move_down 30
      
      totales = [
        ["", ""],
        ["Subtotal:", "$#{'%.2f' % subtotal}"],
        ["IVA (16%):", "$#{'%.2f' % iva}"],
        ["TOTAL:", "$#{'%.2f' % total}"]
      ]
      
      pdf.table(totales, position: :right, width: 250, cell_style: {borders: []}) do |table|
        table.row(0).borders = [:bottom]
        table.row(-1).font_style = :bold
        table.row(-1).size = 12
        table.column(1).align = :right
        table.column(1).width = 100
      end
      
      pdf.move_down 50
      pdf.stroke_horizontal_rule
      pdf.move_down 10
      pdf.text "Condiciones de pago: Pago inmediato", size: 8
      pdf.text "Válido como factura electrónica según normativa vigente", size: 8, style: :italic
      pdf.move_down 10
      pdf.text "Gracias por su preferencia", align: :center, size: 9
      
      pdf.transparent(0.1) do
        pdf.fill_color "cccccc"
        pdf.text_box "FACTURA ##{factura_id}", 
                    at: [100, 400], 
                    size: 60, 
                    rotate: 45, 
                    style: :bold
      end
    end
    
    puts "Factura PDF generada en: #{File.expand_path(output_path)}"
  end
end